<?php
    // show given TAJ ID if exists
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data</title>
</head>
<body>
    Full name: <br>
    E-mail: <br>
    TAJ: <br>
    Age:  <br>
    Gender: <br>
    Registered: <br>
    Notes:  <br>
    <a href="delete.php PARAMETERS">Delete</a> <br>
    <a href="index.php">Back to home</a>
</body>
</html>
