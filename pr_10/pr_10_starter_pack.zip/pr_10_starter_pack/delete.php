<?php
    // no output just delete and redirect
?>
