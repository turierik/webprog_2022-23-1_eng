<?php
    
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
    <form action="reg.php" method="post">
        Full name: <input type="text" name="fullname" value=""> <br>
        E-mail: <input type="text" name="email" value=""> <br>
        TAJ (9 digits): <input type="text" name="taj" value=""> <br>
        Age: <input type="text" name="age" value="">  <br>
        Gender:
            <input type="radio" name="gender" value="m">male
            <input type="radio" name="gender" value="f">female
        <input type="checkbox" name="accept"> Accept terms and conditions. <br>
        Registration date: <input type="date" name="regdate" value="today"><br>
        Notes: <br><textarea name="notes"></textarea><br>
        <button type="submit">Register</button>
    </form>
    <a href="index.php">Back to home</a>
</body>
</html>